/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Cell
} from 'recharts';
import { 
  LayoutDashboard, 
  Package, 
  TrendingUp, 
  Plus, 
  Minus, 
  PlusCircle, 
  Save, 
  CheckCircle2,
  Calendar,
  RotateCcw,
  AlertTriangle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

type View = 'Overview' | 'Sales' | 'Inventory' | 'AddProduct';

interface Product {
  name: string;
  price: number;
  category: string;
}

interface CartItem extends Product {
  quantity: number;
}

interface SavedTransaction {
  id: string;
  items: CartItem[];
  total: number;
  timestamp: string;
}

interface DailyLog {
  date: string;
  totalRevenue: number;
  transactionsCount: number;
  itemsSold: Record<string, number>;
}

const INVENTORY_DATA: Record<string, Product[]> = {
  'Softdrinks': [
    { name: 'Coke (8oz)', price: 13, category: 'Softdrinks' },
    { name: 'M-dew (8oz)', price: 13, category: 'Softdrinks' },
    { name: 'Sprite (8oz)', price: 13, category: 'Softdrinks' },
    { name: 'Cobra (290ml)', price: 18, category: 'Softdrinks' },
    { name: 'Coke (1L)', price: 33, category: 'Softdrinks' },
    { name: 'M-dew (1L)', price: 33, category: 'Softdrinks' },
    { name: 'Zesto (200mL)', price: 12, category: 'Softdrinks' },
    { name: 'Yakult', price: 12, category: 'Softdrinks' }
  ],
  'Biscuit': [
    { name: 'hanseL', price: 10, category: 'Biscuit' },
    { name: 'Combo', price: 10, category: 'Biscuit' },
    { name: 'Presto', price: 10, category: 'Biscuit' },
    { name: 'Oreo', price: 10, category: 'Biscuit' },
    { name: 'Skyflakes', price: 10, category: 'Biscuit' },
    { name: 'Fudgee bar', price: 10, category: 'Biscuit' },
    { name: 'Cloud9', price: 12, category: 'Biscuit' }
  ],
  'Essentials': [
    { name: 'Magic sarap (8g)', price: 6, category: 'Essentials' },
    { name: 'Ginisa mix (8g)', price: 5, category: 'Essentials' },
    { name: 'Mantika (250mL)', price: 40, category: 'Essentials' },
    { name: 'Knor Pork cubes', price: 8, category: 'Essentials' },
    { name: 'Knor Beef cubes', price: 8, category: 'Essentials' },
    { name: 'Knor shrimp cubes', price: 8, category: 'Essentials' },
    { name: 'Crispy fry (30g)', price: 22, category: 'Essentials' },
    { name: 'Betsin (11 g)', price: 5, category: 'Essentials' },
    { name: 'Eden cheese (45g)', price: 25, category: 'Essentials' }
  ],
  'Coffee': [
    { name: 'Kopiko Black (twin pack)', price: 17, category: 'Coffee' },
    { name: 'Kopiko Blanca (twin pack)', price: 17, category: 'Coffee' },
    { name: 'Kopiko Brown (twin pack)', price: 17, category: 'Coffee' },
    { name: 'Nescafe Creamy White (twin pack)', price: 17, category: 'Coffee' },
    { name: 'Milo (small)', price: 11, category: 'Coffee' },
    { name: 'Bearbrand', price: 14, category: 'Coffee' }
  ],
  'Snacks': [
    { name: 'Piattos (small)', price: 20, category: 'Snacks' },
    { name: 'Nova (small)', price: 21, category: 'Snacks' },
    { name: 'Cheesy (small)', price: 10, category: 'Snacks' },
    { name: 'Pillow (small)', price: 11, category: 'Snacks' },
    { name: 'Loaded (small)', price: 10, category: 'Snacks' },
    { name: 'Patata (small)', price: 10, category: 'Snacks' },
    { name: 'Mr.chips (small)', price: 10, category: 'Snacks' },
    { name: 'Vcut (small)', price: 20, category: 'Snacks' }
  ]
};

export default function App() {
  const [currentView, setCurrentView] = useState<View>('Overview');
  const [activeCategory, setActiveCategory] = useState('Softdrinks');
  
  const [productsCatalog, setProductsCatalog] = useState<Record<string, Product[]>>(() => {
    const saved = localStorage.getItem('dashboard_products_catalog');
    if (saved) return JSON.parse(saved);
    return INVENTORY_DATA;
  });

  const [cart, setCart] = useState<CartItem[]>([]);
  const [transactions, setTransactions] = useState<SavedTransaction[]>(() => {
    const saved = localStorage.getItem('dashboard_transactions');
    return saved ? JSON.parse(saved) : [];
  });
  const [dailyLogs, setDailyLogs] = useState<DailyLog[]>(() => {
    const saved = localStorage.getItem('dashboard_daily_logs');
    return saved ? JSON.parse(saved) : [];
  });
  const [stocks, setStocks] = useState<Record<string, number>>(() => {
    const saved = localStorage.getItem('dashboard_stocks');
    if (saved) return JSON.parse(saved);
    // Default initial stock of 25 for all products
    const initialStocks: Record<string, number> = {};
    (Object.values(productsCatalog) as Product[][]).forEach(products => {
      products.forEach(p => {
        initialStocks[p.name] = 25;
      });
    });
    return initialStocks;
  });
  const [stockAction, setStockAction] = useState<'add' | 'remove'>('add');
  
  // Add Product tab form states
  const [newProdName, setNewProdName] = useState('');
  const [newProdPrice, setNewProdPrice] = useState('');
  const [newProdCategory, setNewProdCategory] = useState('');
  const [newProdStock, setNewProdStock] = useState('25');
  const [categoryMode, setCategoryMode] = useState<'existing' | 'new'>('existing');
  const [selectedExistingCategory, setSelectedExistingCategory] = useState('Softdrinks');
  const [productMessage, setProductMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);

  const [showSavedMsg, setShowSavedMsg] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  const resetAllData = () => {
    setTransactions([]);
    setDailyLogs([]);
    setCart([]);
    setProductsCatalog(INVENTORY_DATA);
    
    localStorage.removeItem('dashboard_transactions');
    localStorage.removeItem('dashboard_daily_logs');
    localStorage.removeItem('dashboard_products_catalog');
    
    // Reset stocks back to 25
    const initialStocks: Record<string, number> = {};
    Object.values(INVENTORY_DATA).forEach(products => {
      products.forEach(p => {
        initialStocks[p.name] = 25;
      });
    });
    setStocks(initialStocks);
    localStorage.setItem('dashboard_stocks', JSON.stringify(initialStocks));
    
    setShowResetConfirm(false);
  };

  // Persistence for transactions and reports
  useEffect(() => {
    localStorage.setItem('dashboard_transactions', JSON.stringify(transactions));
    localStorage.setItem('dashboard_daily_logs', JSON.stringify(dailyLogs));
  }, [transactions, dailyLogs]);

  useEffect(() => {
    localStorage.setItem('dashboard_products_catalog', JSON.stringify(productsCatalog));
  }, [productsCatalog]);

  useEffect(() => {
    localStorage.setItem('dashboard_stocks', JSON.stringify(stocks));
  }, [stocks]);

  const adjustStock = (productName: string, delta: number) => {
    setStocks(prev => {
      const current = prev[productName] ?? 25;
      const nextStock = Math.max(0, current + delta);
      return {
        ...prev,
        [productName]: nextStock
      };
    });
  };

  const handleAddProduct = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate inputs
    const trimmedName = newProdName.trim();
    if (!trimmedName) {
      setProductMessage({ type: 'error', text: 'Product name cannot be empty!' });
      return;
    }
    
    const priceNum = parseFloat(newProdPrice);
    if (isNaN(priceNum) || priceNum <= 0) {
      setProductMessage({ type: 'error', text: 'Please enter a valid price greater than 0!' });
      return;
    }
    
    const stockNum = parseInt(newProdStock);
    if (isNaN(stockNum) || stockNum < 0) {
      setProductMessage({ type: 'error', text: 'Initial stock must be a non-negative number!' });
      return;
    }
    
    const categoryToUse = categoryMode === 'existing' 
      ? selectedExistingCategory 
      : newProdCategory.trim();
      
    if (!categoryToUse) {
      setProductMessage({ type: 'error', text: 'Category cannot be empty!' });
      return;
    }
    
    // Check if item already exists
    let exists = false;
    (Object.values(productsCatalog) as Product[][]).forEach(products => {
      if (products.some(p => p.name.toLowerCase() === trimmedName.toLowerCase())) {
        exists = true;
      }
    });
    
    if (exists) {
      setProductMessage({ type: 'error', text: `Product "${trimmedName}" already exists in catalog!` });
      return;
    }
    
    const newProduct: Product = {
      name: trimmedName,
      price: priceNum,
      category: categoryToUse
    };
    
    // Update products catalog
    setProductsCatalog(prev => {
      const updated = { ...prev };
      if (!updated[categoryToUse]) {
        updated[categoryToUse] = [];
      }
      updated[categoryToUse] = [...updated[categoryToUse], newProduct];
      return updated;
    });
    
    // Set stock
    setStocks(prev => ({
      ...prev,
      [trimmedName]: stockNum
    }));
    
    // Reset form fields (except category selection, for fast sequential inputs)
    setNewProdName('');
    setNewProdPrice('');
    setNewProdStock('25');
    if (categoryMode === 'new') {
      setSelectedExistingCategory(categoryToUse);
      setCategoryMode('existing');
      setNewProdCategory('');
    }
    
    setProductMessage({ type: 'success', text: `Successfully added "${trimmedName}"!` });
    setTimeout(() => setProductMessage(null), 3000);
  };

  const handleDeleteProduct = (category: string, productName: string) => {
    // Remove from active cart if it's there
    setCart(prev => prev.filter(item => item.name !== productName));
    
    // Remove from stocks state
    setStocks(prev => {
      const updated = { ...prev };
      delete updated[productName];
      return updated;
    });
    
    // Remove from productsCatalog
    setProductsCatalog(prev => {
      const updated = { ...prev };
      if (updated[category]) {
        updated[category] = updated[category].filter(p => p.name !== productName);
        if (updated[category].length === 0) {
          delete updated[category];
          if (activeCategory === category) {
            const keys = Object.keys(updated);
            if (keys.length > 0) {
              setActiveCategory(keys[0]);
            }
          }
        }
      }
      return updated;
    });
  };

  const totalCartValue = useMemo(() => {
    return cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  }, [cart]);

  const addToCart = (product: Product, quantity: number) => {
    const currentStock = stocks[product.name] ?? 25;
    const inCart = cart.find(item => item.name === product.name)?.quantity ?? 0;
    const available = Math.max(0, currentStock - inCart);

    if (available < quantity) {
      return; // Exceeds available stock, do nothing
    }

    setCart(prev => {
      const existing = prev.find(item => item.name === product.name);
      if (existing) {
        return prev.map(item => 
          item.name === product.name ? { ...item, quantity: item.quantity + quantity } : item
        );
      }
      return [...prev, { ...product, quantity }];
    });
  };

  const updateCartQuantity = (name: string, delta: number) => {
    setCart(prev => {
      const item = prev.find(i => i.name === name);
      if (!item) return prev;

      const currentStock = stocks[name] ?? 25;
      const newQty = item.quantity + delta;

      if (delta > 0 && newQty > currentStock) {
        return prev; // Exceeds available stock
      }

      return prev.map(item => {
        if (item.name === name) {
          const updatedQty = Math.max(0, item.quantity + delta);
          return { ...item, quantity: updatedQty };
        }
        return item;
      }).filter(item => item.quantity > 0);
    });
  };

  const saveTransaction = () => {
    if (cart.length === 0) return;
    
    const newTransaction: SavedTransaction = {
      id: Math.random().toString(36).substring(2, 9),
      items: [...cart],
      total: totalCartValue,
      timestamp: new Date().toISOString()
    };

    // Deduct quantities from stocks
    setStocks(prev => {
      const updated = { ...prev };
      cart.forEach(item => {
        updated[item.name] = Math.max(0, (updated[item.name] ?? 25) - item.quantity);
      });
      return updated;
    });
    
    setTransactions(prev => [newTransaction, ...prev]);
    setCart([]);
    setShowSavedMsg(true);
    setTimeout(() => setShowSavedMsg(false), 3000);
  };

  const commitDailySales = () => {
    if (transactions.length === 0) return;
    
    setIsSyncing(true);
    
    // Aggregate data
    const today = new Date().toISOString().split('T')[0];
    const totalRevenue = transactions.reduce((sum, t) => sum + t.total, 0);
    const itemsSold: Record<string, number> = {};
    
    transactions.forEach(t => {
      t.items.forEach(item => {
        itemsSold[item.name] = (itemsSold[item.name] || 0) + item.quantity;
      });
    });

    const newLog: DailyLog = {
      date: today,
      totalRevenue,
      transactionsCount: transactions.length,
      itemsSold
    };

    setTimeout(() => {
      setDailyLogs(prev => {
        // Check if report for today already exists to avoid duplicates
        const existingIndex = prev.findIndex(l => l.date === today);
        if (existingIndex > -1) {
          const updated = [...prev];
          updated[existingIndex] = newLog;
          return updated;
        }
        return [newLog, ...prev];
      });
      // Optionally clear transactions after committing
      // setTransactions([]); 
      setIsSyncing(false);
    }, 800);
  };

  const stats = {
    netIncome: transactions.reduce((sum, t) => sum + t.total, 0),
    totalTransactions: transactions.length,
    lifetimeRevenue: dailyLogs.reduce((sum, log) => sum + log.totalRevenue, 0)
  };

  const productsRanked = useMemo(() => {
    const counts: Record<string, number> = {};
    dailyLogs.forEach(log => {
      Object.entries(log.itemsSold).forEach(([name, qty]) => {
        counts[name] = (counts[name] || 0) + (qty as number);
      });
    });
    return Object.entries(counts).sort((a, b) => b[1] - a[1]);
  }, [dailyLogs]);

  const lowStockProducts = useMemo(() => {
    const lowItems: { name: string; category: string; stock: number }[] = [];
    (Object.entries(productsCatalog) as [string, Product[]][]).forEach(([category, products]) => {
      products.forEach(p => {
        const s = stocks[p.name] ?? 25;
        if (s <= 5) {
          lowItems.push({ name: p.name, category, stock: s });
        }
      });
    });
    return lowItems;
  }, [stocks, productsCatalog]);



  const chartData = useMemo(() => {
    return [...dailyLogs]
      .reverse() // Chronological order
      .slice(-7) // Last 7 logs
      .map(log => ({
        name: new Date(log.date).toLocaleDateString(undefined, { weekday: 'short' }),
        revenue: log.totalRevenue,
        fullDate: log.date
      }));
  }, [dailyLogs]);

  return (
    <div className="flex h-screen w-full dashboard-gradient">
      {/* Sidebar */}
      <aside className="w-72 sidebar-navy flex flex-col p-8 text-white shadow-2xl">
        <h1 className="text-4xl font-bold italic tracking-tighter mb-16 px-4">Menu</h1>
        
        <nav className="flex flex-col gap-4">
          <SidebarLink 
            icon={<LayoutDashboard size={24} />} 
            label="Overview" 
            active={currentView === 'Overview'} 
            onClick={() => setCurrentView('Overview')} 
          />
          <SidebarLink 
            icon={<TrendingUp size={24} />} 
            label="Sales" 
            active={currentView === 'Sales'} 
            onClick={() => setCurrentView('Sales')} 
          />
          <SidebarLink 
            icon={<Package size={24} />} 
            label="Inventory" 
            active={currentView === 'Inventory'} 
            onClick={() => setCurrentView('Inventory')} 
          />
          <SidebarLink 
            icon={<PlusCircle size={24} />} 
            label="Add Product" 
            active={currentView === 'AddProduct'} 
            onClick={() => setCurrentView('AddProduct')} 
          />
        </nav>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto p-12">
        <AnimatePresence mode="wait">
          {currentView === 'Overview' && (
            <motion.div 
              key="overview"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-10"
            >
              <header className="flex justify-end">
                <div className="pill-container flex items-center gap-2">
                  <Calendar size={18} className="text-neutral-400" />
                  <span>{new Date().toLocaleDateString('en-PH', { month: 'long', year: 'numeric' })}</span>
                </div>
              </header>

              {/* Low Stock Notifications */}
              {lowStockProducts.length > 0 && (
                <div className="bg-rose-50 border-[3.5px] border-rose-200 rounded-[30px] p-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-sm">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-rose-100 flex items-center justify-center text-rose-600 border-[2.5px] border-rose-200 shrink-0 mt-0.5">
                      <AlertTriangle size={24} strokeWidth={2.5} />
                    </div>
                    <div>
                      <h4 className="font-black text-rose-900 uppercase tracking-wider text-sm flex items-center gap-2">
                        Low Stock Alert
                        <span className="h-5 w-5 rounded-full bg-rose-600 text-white text-[10px] flex items-center justify-center font-black animate-pulse">
                          {lowStockProducts.length}
                        </span>
                      </h4>
                      <p className="text-xs text-rose-700/80 font-bold mt-1">
                        These items are running critically low (5 units or less). Ensure these are replenished immediately:
                      </p>
                      <div className="flex flex-wrap gap-2 mt-3">
                        {lowStockProducts.map(p => (
                          <span key={p.name} className="px-3 py-1 bg-white border border-rose-200 text-rose-700 text-[10px] font-black uppercase tracking-wider rounded-xl shadow-xs">
                            {p.name}: <span className="text-red-600 font-extrabold">{p.stock}</span> left
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                  <button 
                    onClick={() => setCurrentView('Inventory')}
                    className="px-5 py-3 bg-red-600 hover:bg-neutral-800 text-white rounded-2xl font-black text-xs uppercase tracking-widest transition-all active:scale-95 flex items-center gap-1.5 shadow-md self-end md:self-center whitespace-nowrap"
                  >
                    Restock Now
                  </button>
                </div>
              )}

              <section className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="card-container">
                  <h2 className="text-2xl font-bold text-navy mb-4">Net Income</h2>
                  <div className="text-5xl font-black text-neutral-800 tracking-tight">
                    ₱{stats.netIncome.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </div>
                </div>
                <div className="card-container">
                  <h2 className="text-2xl font-bold text-navy mb-4">Transactions</h2>
                  <div className="text-5xl font-black text-neutral-800 tracking-tight">
                    {stats.totalTransactions}
                  </div>
                </div>
              </section>

              <section className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="card-container min-h-[400px]">
                  <h2 className="text-2xl font-bold text-navy mb-6">Recent Activity</h2>
                  <div className="space-y-4">
                    {transactions.length === 0 ? (
                      <p className="text-neutral-400 italic text-center mt-20">Transaction history will appear here.</p>
                    ) : (
                      transactions.slice(0, 5).map(t => (
                        <div key={t.id} className="flex items-center justify-between p-4 bg-neutral-50 rounded-2xl border border-neutral-100">
                          <div>
                            <p className="font-bold text-sm">{t.items.length} items</p>
                            <p className="text-[10px] text-neutral-400">{new Date(t.timestamp).toLocaleTimeString()}</p>
                          </div>
                          <p className="font-black text-navy">₱{t.total.toFixed(2)}</p>
                        </div>
                      ))
                    )}
                  </div>
                </div>
                <div className="card-container min-h-[400px] relative">
                  <div className="flex justify-between items-start mb-6">
                    <h2 className="text-2xl font-bold text-navy">Sales & Revenue</h2>
                    <button 
                      onClick={commitDailySales}
                      disabled={isSyncing || transactions.length === 0}
                      className="p-3 bg-navy text-white rounded-2xl hover:bg-neutral-800 disabled:opacity-30 disabled:cursor-not-allowed transition-all active:scale-95 shadow-lg flex items-center gap-2 group"
                      title="Save today's sales to history"
                    >
                      {isSyncing ? (
                         <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full" />
                      ) : (
                        <Save size={18} className="group-hover:scale-110 transition-transform" />
                      )}
                      <span className="text-xs font-bold uppercase tracking-widest hidden sm:inline">Commit</span>
                    </button>
                  </div>
                  <div className="flex flex-col gap-6 h-full pb-12">
                    <div className="flex items-center justify-between p-6 bg-navy text-white rounded-[30px] border-[4px] border-border-gray/20">
                      <div>
                        <p className="text-[10px] font-black uppercase tracking-[0.2em] opacity-60">Pending Deposit</p>
                        <p className="text-3xl font-black italic tracking-tighter">₱{stats.netIncome.toFixed(2)}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-[10px] font-black uppercase tracking-[0.2em] opacity-60">Active Queue</p>
                        <p className="text-xl font-black italic tracking-tighter">{stats.totalTransactions} Sold</p>
                      </div>
                    </div>
                    
                    <div className="mt-4 flex-1">
                      <p className="text-[10px] font-black uppercase tracking-[0.2em] text-neutral-400 mb-4">Historical Growth</p>
                      {dailyLogs.length === 0 ? (
                        <div className="flex flex-col items-center justify-center py-10 opacity-20">
                          <TrendingUp size={32} />
                          <p className="text-[10px] font-bold mt-2 uppercase tracking-widest">No history synced</p>
                        </div>
                      ) : (
                        <div className="space-y-3">
                          {dailyLogs.slice(0, 3).map(log => (
                            <div key={log.date} className="flex justify-between items-center text-sm">
                              <span className="text-neutral-500 font-bold">{new Date(log.date).toLocaleDateString()}</span>
                              <span className="font-black text-navy">₱{log.totalRevenue.toFixed(0)}</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </section>

              <div className="flex justify-end pt-4">
                <button
                  onClick={() => setShowResetConfirm(true)}
                  className="px-6 py-3 bg-red-50 hover:bg-red-100 text-red-600 border-[3px] border-red-200 hover:border-red-400 rounded-full font-black text-xs uppercase tracking-widest transition-all active:scale-95 flex items-center gap-2 shadow-sm"
                  title="Clear all stored sales and transactions for a fresh start"
                >
                  <RotateCcw size={14} />
                  Reset Database
                </button>
              </div>
            </motion.div>
          )}

          {currentView === 'Sales' && (
            <motion.div 
              key="sales"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-10"
            >
              <header className="flex justify-between items-center">
                <div className="pill-container flex items-center gap-2 px-10 py-4 text-xl">
                  Monthly Performance
                </div>
                <div className="text-right">
                  <p className="text-[10px] font-black uppercase tracking-[0.2em] text-neutral-400">Total Lifecycle Sales</p>
                  <p className="text-3xl font-black italic text-navy">₱{stats.lifetimeRevenue.toLocaleString()}</p>
                </div>
              </header>

              <section className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="space-y-4">
                  <div className="inline-block bg-white border-[3px] border-border-gray rounded-2xl px-6 py-1 font-bold text-sm ml-6 mb-[-20px] relative z-10">
                    Products Sold
                  </div>
                  <div className="card-container min-h-[500px] bg-neutral-50">
                    {productsRanked.length === 0 ? (
                      <p className="text-neutral-400 italic text-center mt-40">List of products will appear here after syncing.</p>
                    ) : (
                      <div className="space-y-4 pt-4">
                        {productsRanked.map(([name, qty]) => (
                          <div key={name} className="flex items-center justify-between p-5 bg-white rounded-3xl border border-neutral-200 shadow-sm transition-all hover:scale-[1.02]">
                            <div className="flex items-center gap-4">
                              <div className="w-10 h-10 bg-navy text-white rounded-xl flex items-center justify-center font-black text-xs italic">
                                #{productsRanked.findIndex(x => x[0] === name) + 1}
                              </div>
                              <span className="font-bold text-navy uppercase tracking-tight">{name}</span>
                            </div>
                            <div className="text-right">
                              <span className="font-black text-xl italic text-neutral-800">{qty}</span>
                              <p className="text-[10px] font-bold text-neutral-400 uppercase tracking-widest">Units Sold</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
                <div className="space-y-4">
                   <div className="inline-block bg-white border-[3px] border-border-gray rounded-2xl px-6 py-1 font-bold text-sm ml-6 mb-[-20px] relative z-10">
                    Revenue Stream
                  </div>
                  <div className="card-container min-h-[500px] bg-neutral-50 flex flex-col">
                    {dailyLogs.length === 0 ? (
                      <p className="text-neutral-400 italic text-center mt-40">Sales data or charts will appear here.</p>
                    ) : (
                      <>
                        <div className="h-[250px] mb-8 w-full pt-4">
                          <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={chartData}>
                              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E5E5" />
                              <XAxis 
                                dataKey="name" 
                                axisLine={false} 
                                tickLine={false} 
                                tick={{ fontSize: 10, fontWeight: 700, fill: '#A3A3A3' }}
                              />
                              <YAxis 
                                axisLine={false} 
                                tickLine={false} 
                                tick={{ fontSize: 10, fontWeight: 700, fill: '#A3A3A3' }}
                                tickFormatter={(val) => `₱${val}`}
                              />
                              <Tooltip 
                                contentStyle={{ borderRadius: '20px', border: '3px solid #d1d8dd', fontWeight: 'bold' }}
                                formatter={(value: number) => [`₱${value.toFixed(2)}`, 'Revenue']}
                              />
                              <Bar 
                                dataKey="revenue" 
                                radius={[10, 10, 0, 0]}
                                barSize={40}
                              >
                                {chartData.map((_entry, index) => (
                                  <Cell key={`cell-${index}`} fill={index === chartData.length - 1 ? '#1a262b' : '#d1d8dd'} />
                                ))}
                              </Bar>
                            </BarChart>
                          </ResponsiveContainer>
                        </div>

                        <div className="space-y-3 flex-1 overflow-y-auto pr-2 custom-scrollbar">
                          {dailyLogs.map(log => (
                            <div key={log.date} className="flex items-center justify-between p-5 bg-white rounded-3xl border border-neutral-200 shadow-sm">
                               <div>
                                  <p className="font-bold text-navy">{new Date(log.date).toLocaleDateString(undefined, { weekday: 'long', month: 'short', day: 'numeric' })}</p>
                                  <p className="text-[10px] text-neutral-400 font-bold uppercase tracking-widest">{log.transactionsCount} Transactions</p>
                               </div>
                               <div className="text-right">
                                  <p className="font-black text-xl text-neutral-800">₱{log.totalRevenue.toFixed(2)}</p>
                               </div>
                            </div>
                          ))}
                        </div>
                      </>
                    )}
                  </div>
                </div>
              </section>
            </motion.div>
          )}

          {currentView === 'Inventory' && (
            <motion.div 
              key="inventory"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="flex flex-col h-full gap-8"
            >
              <div className="grid grid-cols-1 lg:grid-cols-5 gap-8 flex-1">
                {/* Product Catalog */}
                <div className="lg:col-span-3 card-container flex flex-col h-full bg-white">
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
                    <h2 className="text-2xl font-bold text-navy">Catalog</h2>
                    
                    {/* Stock Adjustment Action Selector */}
                    <div className="flex flex-col gap-1 items-start sm:items-end">
                      <span className="text-[9px] font-black uppercase tracking-[0.15em] text-neutral-400">Stock Adjustment Mode:</span>
                      <div className="flex items-center gap-1 bg-neutral-100 p-1 rounded-xl border border-neutral-200">
                        <button 
                          onClick={() => setStockAction('add')}
                          className={`px-3 py-1.5 rounded-lg text-xs font-black uppercase tracking-wider transition-all flex items-center gap-1 ${
                            stockAction === 'add' 
                              ? 'bg-emerald-600 text-white shadow-sm' 
                              : 'text-neutral-500 hover:text-neutral-800 hover:bg-neutral-200/50'
                          }`}
                        >
                          <Plus size={12} strokeWidth={3} />
                          + Add Stock
                        </button>
                        <button 
                          onClick={() => setStockAction('remove')}
                          className={`px-3 py-1.5 rounded-lg text-xs font-black uppercase tracking-wider transition-all flex items-center gap-1 ${
                            stockAction === 'remove' 
                              ? 'bg-rose-600 text-white shadow-sm' 
                              : 'text-neutral-500 hover:text-neutral-800 hover:bg-neutral-200/50'
                          }`}
                        >
                          <Minus size={12} strokeWidth={3} />
                          - Remove Stock
                        </button>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex gap-3 mb-6 overflow-x-auto pb-2">
                    {Object.keys(productsCatalog).map(cat => (
                      <button 
                        key={cat}
                        onClick={() => setActiveCategory(cat)}
                        className={`px-6 py-2 rounded-full font-bold text-sm border-[3px] transition-all whitespace-nowrap ${
                          activeCategory === cat 
                            ? 'bg-navy text-white border-navy shadow-lg' 
                            : 'bg-white text-neutral-500 border-neutral-200 hover:border-navy'
                        }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>

                  <div className="flex-1 bg-neutral-50 rounded-[30px] border-[2px] border-neutral-200 p-6 overflow-y-auto">
                    <div className="space-y-4">
                      {(productsCatalog[activeCategory] || []).map(prod => {
                        const currentStock = stocks[prod.name] ?? 25;
                        const inCartQty = cart.find(item => item.name === prod.name)?.quantity ?? 0;
                        const availableStock = Math.max(0, currentStock - inCartQty);
                        
                        return (
                          <div key={prod.name} className="flex flex-col sm:flex-row sm:items-center justify-between p-4 bg-white border border-neutral-200 rounded-3xl group hover:shadow-sm transition-all gap-4">
                            <div className="space-y-1">
                              <p className="font-extrabold text-navy uppercase tracking-tight text-base text-left">{prod.name}</p>
                              <div className="flex flex-wrap items-center gap-2">
                                <span className="text-xs text-neutral-500 font-neutral font-black">₱{prod.price.toFixed(2)}</span>
                                <span className="h-3 w-[1px] bg-neutral-200" />
                                <span className={`text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full ${
                                  currentStock === 0 
                                    ? 'bg-rose-50 text-rose-600 border border-rose-200/60' 
                                    : currentStock <= 5 
                                      ? 'bg-amber-50 text-amber-600 border border-amber-200/60' 
                                      : 'bg-emerald-50 text-emerald-600 border border-emerald-200/30'
                                }`}>
                                  Stock: {currentStock}
                                </span>
                                {inCartQty > 0 && (
                                  <span className="text-[10px] font-extrabold text-indigo-600 bg-indigo-50 border border-indigo-100 px-2 py-0.5 rounded-full">
                                    {inCartQty} in cart
                                  </span>
                                )}
                              </div>
                            </div>

                            <div className="flex items-center gap-2.5">
                              {/* Stock Adjuster Button */}
                              <button 
                                onClick={() => adjustStock(prod.name, stockAction === 'add' ? 1 : -1)}
                                className={`px-3 py-2 rounded-xl border-[2.5px] font-black text-xs uppercase tracking-widest transition-all active:scale-95 flex items-center gap-1.5 ${
                                  stockAction === 'add'
                                    ? 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100 hover:border-emerald-300'
                                    : 'bg-rose-50 text-rose-600 border-rose-200 hover:bg-rose-100 hover:border-rose-300'
                                }`}
                                title={stockAction === 'add' ? 'Increase Stock by 1' : 'Decrease Stock by 1'}
                              >
                                {stockAction === 'add' ? <Plus size={12} strokeWidth={3} /> : <Minus size={12} strokeWidth={3} />}
                                {stockAction === 'add' ? 'Add Stock' : 'Remove Stock'}
                              </button>

                              {/* POS Add to Cart Button */}
                              {availableStock === 0 ? (
                                <span className="px-4 py-2 bg-neutral-100 border-[2.5px] border-neutral-200 text-neutral-400 rounded-xl font-extrabold text-xs uppercase tracking-widest cursor-not-allowed">
                                  Sold Out
                                </span>
                              ) : (
                                <button 
                                  onClick={() => addToCart(prod, 1)}
                                  className="p-2 bg-navy text-white rounded-xl hover:bg-neutral-800 active:scale-95 transition-all shadow-md flex items-center gap-1 text-xs font-black uppercase tracking-widest px-4 py-2"
                                >
                                  <PlusCircle size={14} />
                                  + Cart
                                </button>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>

                {/* Selected Items / Cart */}
                <div className="lg:col-span-2 card-container flex flex-col bg-neutral-50">
                  <h2 className="text-2xl font-bold text-navy mb-6">Cart</h2>
                  <div className="flex-1 overflow-y-auto space-y-3">
                    {cart.length === 0 ? (
                      <div className="flex flex-col items-center justify-center mt-24 text-neutral-300">
                        <Package size={48} strokeWidth={1} />
                        <p className="text-[10px] font-black uppercase tracking-[0.3em] mt-4">Empty Queue</p>
                      </div>
                    ) : (
                      cart.map(item => (
                        <div key={item.name} className="flex items-center justify-between p-4 bg-white rounded-2xl border border-neutral-200">
                          <div className="flex-1">
                            <p className="font-bold text-sm text-navy uppercase tracking-tight">{item.name}</p>
                            <p className="text-[10px] text-neutral-400 font-bold">₱{(item.price * item.quantity).toFixed(2)}</p>
                          </div>
                          <div className="flex items-center gap-3 bg-neutral-50 px-3 py-1.5 rounded-xl border border-neutral-200">
                            <button 
                              onClick={() => updateCartQuantity(item.name, -1)}
                              className="text-neutral-400 hover:text-navy transition-colors"
                            >
                              <Minus size={14} />
                            </button>
                            <span className="font-black text-xs w-6 text-center">{item.quantity}</span>
                            <button 
                              onClick={() => updateCartQuantity(item.name, 1)}
                              className="text-neutral-400 hover:text-navy transition-colors"
                            >
                              <Plus size={14} />
                            </button>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>

              {/* Action Bar */}
              <footer className="flex items-center justify-between">
                <div className="pill-container text-2xl px-12 py-4">
                  Total: <span className="text-navy font-black ml-2 tracking-tighter">₱{totalCartValue.toFixed(2)}</span>
                </div>
                
                <div className="flex items-center gap-6">
                  <AnimatePresence>
                    {showSavedMsg && (
                      <motion.div 
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: 20 }}
                        className="flex items-center gap-2 text-navy font-black uppercase tracking-widest text-xs"
                      >
                        <CheckCircle2 size={20} className="text-green-500" />
                        <span>Transaction Logged</span>
                      </motion.div>
                    )}
                  </AnimatePresence>
                  <button 
                    onClick={saveTransaction}
                    disabled={cart.length === 0}
                    className="bg-white border-[4px] border-border-gray hover:border-navy hover:text-navy px-16 py-4 rounded-[30px] font-black text-xl tracking-widest disabled:opacity-30 disabled:cursor-not-allowed transition-all active:scale-95 shadow-lg group italic"
                  >
                    SAVE
                  </button>
                </div>
              </footer>
            </motion.div>
          )}

          {currentView === 'AddProduct' && (
            <motion.div 
              key="add-product"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-10"
            >
              <header className="flex justify-between items-center">
                <div className="pill-container flex items-center gap-2 px-10 py-4 text-xl font-bold bg-white border-[3px] border-neutral-200 text-navy rounded-3xl">
                  Product Management
                </div>
              </header>

              <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
                {/* Left Column: Form to Add Product */}
                <div className="lg:col-span-2 card-container bg-white flex flex-col justify-between p-8 rounded-[30px] border-[4px] border-border-gray shadow-md">
                  <div>
                    <h2 className="text-2xl font-black italic tracking-tighter text-navy mb-2 uppercase">Create Product</h2>
                    <p className="text-xs text-neutral-400 font-bold mb-6">Create new entries in your store inventory.</p>

                    {productMessage && (
                      <div className={`p-4 rounded-2xl mb-6 text-xs font-black uppercase tracking-wider border-[3px] ${
                        productMessage.type === 'success' 
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200' 
                          : 'bg-rose-50 text-rose-600 border-rose-200'
                      }`}>
                        {productMessage.text}
                      </div>
                    )}

                    <form onSubmit={handleAddProduct} className="space-y-5">
                      <div>
                        <label className="block text-[10px] font-black uppercase tracking-[0.2em] text-neutral-400 mb-2">Category Selection</label>
                        <div className="flex gap-2 p-1 bg-neutral-100 rounded-2xl border border-neutral-200 mb-3">
                          <button
                            type="button"
                            onClick={() => setCategoryMode('existing')}
                            className={`flex-1 py-2 text-xs font-black uppercase tracking-wider rounded-xl transition-all ${
                              categoryMode === 'existing'
                                ? 'bg-navy text-white shadow-sm'
                                : 'text-neutral-500 hover:text-neutral-800'
                            }`}
                          >
                            Existing Group
                          </button>
                          <button
                            type="button"
                            onClick={() => setCategoryMode('new')}
                            className={`flex-1 py-2 text-xs font-black uppercase tracking-wider rounded-xl transition-all ${
                              categoryMode === 'new'
                                ? 'bg-navy text-white shadow-sm'
                                : 'text-neutral-500 hover:text-neutral-800'
                            }`}
                          >
                            New Group
                          </button>
                        </div>

                        {categoryMode === 'existing' ? (
                          <select
                            value={selectedExistingCategory}
                            onChange={(e) => setSelectedExistingCategory(e.target.value)}
                            className="w-full bg-white border-[3px] border-neutral-200 rounded-2xl p-3 text-sm font-bold text-navy focus:border-navy focus:outline-none tracking-tight transition-all cursor-pointer"
                          >
                            {Object.keys(productsCatalog).map(cat => (
                              <option key={cat} value={cat}>{cat}</option>
                            ))}
                          </select>
                        ) : (
                          <input
                            type="text"
                            value={newProdCategory}
                            onChange={(e) => setNewProdCategory(e.target.value)}
                            placeholder="e.g. Household, Spices, Ice Cream"
                            className="w-full bg-white border-[3px] border-neutral-200 rounded-2xl p-3 text-sm font-bold text-navy focus:border-navy focus:outline-none tracking-tight transition-all"
                          />
                        )}
                      </div>

                      <div>
                        <label className="block text-[10px] font-black uppercase tracking-[0.2em] text-neutral-400 mb-2">Product Name</label>
                        <input
                          type="text"
                          value={newProdName}
                          onChange={(e) => setNewProdName(e.target.value)}
                          placeholder="e.g. Sprite (1.5L), Magic Crackers"
                          className="w-full bg-white border-[3px] border-neutral-200 rounded-2xl p-3 text-sm font-bold text-navy focus:border-navy focus:outline-none tracking-tight transition-all"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-[10px] font-black uppercase tracking-[0.2em] text-neutral-400 mb-2">Price (₱)</label>
                          <input
                            type="number"
                            step="0.01"
                            value={newProdPrice}
                            onChange={(e) => setNewProdPrice(e.target.value)}
                            placeholder="0.00"
                            className="w-full bg-white border-[3px] border-neutral-200 rounded-2xl p-3 text-sm font-bold text-navy focus:border-navy focus:outline-none tracking-tight transition-all"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] font-black uppercase tracking-[0.2em] text-neutral-400 mb-2">Initial Stock</label>
                          <input
                            type="number"
                            value={newProdStock}
                            onChange={(e) => setNewProdStock(e.target.value)}
                            placeholder="25"
                            className="w-full bg-white border-[3px] border-neutral-200 rounded-2xl p-3 text-sm font-bold text-navy focus:border-navy focus:outline-none tracking-tight transition-all"
                          />
                        </div>
                      </div>

                      <button
                        type="submit"
                        className="w-full h-14 bg-navy hover:bg-neutral-800 text-white rounded-2xl font-black text-sm uppercase tracking-widest transition-all active:scale-95 shadow-lg flex items-center justify-center gap-2 cursor-pointer"
                      >
                        <PlusCircle size={18} />
                        Save Product
                      </button>
                    </form>
                  </div>
                </div>

                {/* Right Column: Manage Catalog with delete function */}
                <div className="lg:col-span-3 card-container bg-white flex flex-col p-8 rounded-[30px] border-[4px] border-border-gray shadow-md min-h-[500px]">
                  <h2 className="text-2xl font-bold text-navy mb-2">Current Catalog Items</h2>
                  <p className="text-xs text-neutral-400 font-bold mb-6">Review your overall product selection or remove items.</p>

                  <div className="flex-1 overflow-y-auto space-y-6 max-h-[550px] pr-2 custom-scrollbar">
                    {(Object.entries(productsCatalog) as [string, Product[]][]).map(([category, products]) => (
                      <div key={category} className="space-y-3">
                        <div className="flex items-center justify-between border-b border-neutral-200 pb-2">
                          <span className="text-xs font-black uppercase tracking-widest text-neutral-400">{category}</span>
                          <span className="text-[10px] font-black text-neutral-400 bg-neutral-100 px-2.5 py-0.5 rounded-full">{products.length} Products</span>
                        </div>
                        
                        <div className="space-y-2">
                          {products.map(p => {
                            const stockCount = stocks[p.name] ?? 25;
                            return (
                              <div key={p.name} className="flex justify-between items-center p-4 bg-neutral-50 rounded-2xl border border-neutral-200 hover:shadow-xs transition-shadow">
                                <div className="space-y-1">
                                  <p className="font-bold text-sm text-navy uppercase tracking-tight">{p.name}</p>
                                  <div className="flex items-center gap-2">
                                    <span className="text-xs font-bold text-neutral-500">₱{p.price.toFixed(2)}</span>
                                    <span className="h-3 w-[1px] bg-neutral-200" />
                                    <span className="text-[10px] font-extrabold text-neutral-400">Stock: {stockCount}</span>
                                  </div>
                                </div>
                                <button
                                  type="button"
                                  onClick={() => {
                                    if (confirm(`Are you sure you want to delete "${p.name}"? This will clear its trackable stock.`)) {
                                      handleDeleteProduct(category, p.name);
                                    }
                                  }}
                                  className="p-2 border-[2.5px] border-rose-100 hover:border-rose-400 text-rose-50 hover:bg-rose-50 rounded-xl transition-all active:scale-95 flex items-center justify-center cursor-pointer"
                                  title="Delete Product"
                                >
                                  <Minus size={14} strokeWidth={3} />
                                </button>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    ))}
                    {Object.keys(productsCatalog).length === 0 && (
                      <p className="text-neutral-400 italic text-center mt-20">Your catalog is empty. Add a product to get started.</p>
                    )}
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>



      {/* Reset Confirmation Custom Modal */}
      <AnimatePresence>
        {showResetConfirm && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowResetConfirm(false)}
              className="absolute inset-0 bg-neutral-900/60 backdrop-blur-md"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 30 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 30 }}
              className="relative w-full max-w-md bg-white border-[4px] border-border-gray rounded-[30px] shadow-2xl overflow-hidden p-8 z-10"
            >
              <div className="text-center space-y-6">
                <div className="mx-auto w-16 h-16 bg-red-50 text-red-600 rounded-full flex items-center justify-center border-2 border-red-200">
                  <RotateCcw size={28} />
                </div>
                
                <div className="space-y-2">
                  <h3 className="text-2xl font-black italic text-navy uppercase tracking-tighter">Reset All Data?</h3>
                  <p className="text-sm text-neutral-500 font-bold leading-relaxed">
                    This action will clear all transactions, historical sales logs, and current items in the cart back to <span className="text-red-600 font-extrabold">0</span>. This cannot be undone.
                  </p>
                </div>

                <div className="flex items-center gap-4 pt-4 border-t border-neutral-100">
                  <button 
                    type="button"
                    onClick={() => setShowResetConfirm(false)}
                    className="flex-1 h-12 border-[3px] border-border-gray hover:border-navy hover:text-navy rounded-xl text-neutral-500 font-black text-xs uppercase tracking-widest transition-all active:scale-95"
                  >
                    Cancel
                  </button>
                  <button 
                    type="button"
                    onClick={resetAllData}
                    className="flex-1 h-12 bg-red-600 hover:bg-red-700 text-white font-black text-xs uppercase tracking-widest rounded-xl transition-all shadow-md active:scale-95 flex items-center justify-center gap-2"
                  >
                    Yes, Reset
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}

function SidebarLink({ icon, label, active, onClick }: { icon: React.ReactNode, label: string, active?: boolean, onClick: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={`group flex items-center gap-4 px-6 py-5 rounded-[20px] transition-all relative overflow-hidden ${
        active 
          ? 'bg-neutral-700/50 text-white shadow-inner' 
          : 'text-neutral-400 hover:text-white hover:bg-neutral-800'
      }`}
    >
      <span className={`${active ? 'text-white' : 'text-neutral-500 group-hover:text-white'} transition-colors`}>
        {icon}
      </span>
      <span className="text-xl font-bold">{label}</span>
      {active && (
        <motion.div 
          layoutId="active-nav"
          className="absolute left-0 top-0 bottom-0 w-2 bg-white rounded-r-full" 
        />
      )}
    </button>
  );
}
